import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


//Autor: Rodrigo Faltz

public class HotelCasais extends JFrame {

    static class Graph {
        private final int V; // Número de vértices
        private final List<List<Integer>> adj; // Lista de adjacência

        
        public Graph(int V) {
            this.V = V;
            adj = new ArrayList<>(V);
            for (int i = 0; i < V; i++) {
                adj.add(new ArrayList<>());
            }
        }

        // Método para adicionar uma aresta ao grafo
        public void addEdge(int u, int v) {
            adj.get(u).add(v);
        }

        // Retorna verdadeiro se houver um emparelhamento aumentado para o vértice u
        private boolean bpm(int u, boolean[] seen, int[] matchR) {
            for (int v : adj.get(u)) {
                // Se v não foi visitado
                if (!seen[v]) {
                    seen[v] = true; 

                    // Se v não está emparelhado ou o vértice emparelhado com v pode encontrar outro
                    if (matchR[v] < 0 || bpm(matchR[v], seen, matchR)) {
                        matchR[v] = u;
                        return true;
                    }
                }
            }
            return false;
        }

        
        public int maxBipartiteMatching(int[] matchR) {
            // Inicialmente, nenhum vértice está emparelhado
            Arrays.fill(matchR, -1);

            int result = 0; 
            for (int u = 0; u < V / 2; u++) { 
                // Vértices visitados são resetados para cada nó u
                boolean[] seen = new boolean[V];
                // Se o vértice u pode ser emparelhado
                if (bpm(u, seen, matchR)) {
                    result++;
                }
            }
            return result;
        }
    }

    // Classe para o painel onde o grafo será desenhado
    class GraphPanel extends JPanel {
        private final int[] matchR;

        public GraphPanel(int[] matchR) {
            this.matchR = matchR;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int[] casalX = {100, 100, 100, 100, 100, 100}; // Posições X dos casais
            int[] casalY = {50, 100, 150, 200, 250, 300};  // Posições Y dos casais
            int[] quartoX = {300, 300, 300, 300, 300, 300}; // Posições X dos quartos
            int[] quartoY = {50, 100, 150, 200, 250, 300};  // Posições Y dos quartos

            // Desenha os vértices dos casais
            for (int i = 0; i < 6; i++) {
                g2d.setColor(Color.BLUE);
                g2d.fillOval(casalX[i] - 15, casalY[i] - 15, 30, 30);
                g2d.setColor(Color.BLACK);
                g2d.drawString("Casal " + (char) ('A' + i), casalX[i] - 25, casalY[i] - 25);
            }

            // Desenha os vértices dos quartos
            for (int i = 0; i < 6; i++) {
                g2d.setColor(Color.RED);
                g2d.fillOval(quartoX[i] - 15, quartoY[i] - 15, 30, 30);
                g2d.setColor(Color.BLACK);
                g2d.drawString("Quarto " + (i + 1), quartoX[i] + 20, quartoY[i] - 5);
            }

            // Desenha as arestas que representam o emparelhamento
            g2d.setColor(Color.GREEN);
            for (int i = 6; i < 12; i++) {
                if (matchR[i] != -1) {
                    int casalIndex = matchR[i];
                    int quartoIndex = i - 6;
                    g2d.drawLine(casalX[casalIndex], casalY[casalIndex], quartoX[quartoIndex], quartoY[quartoIndex]);
                }
            }
        }
    }

    public HotelCasais(int[] matchR) {
        setTitle("Grafo de Emparelhamento");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        
        add(new GraphPanel(matchR));
    }

    public static void main(String[] args) {
        
        Graph g = new Graph(12); 

        // Conectando os casais aos quartos de acordo com as preferências
        g.addEdge(0, 6); // Casal A - Quarto 1
        g.addEdge(0, 7); // Casal A - Quarto 2
        g.addEdge(0, 9); // Casal A - Quarto 4

        g.addEdge(1, 7); // Casal B - Quarto 2
        g.addEdge(1, 11); // Casal B - Quarto 6

        g.addEdge(2, 7); // Casal C - Quarto 2
        g.addEdge(2, 8); // Casal C - Quarto 3

        g.addEdge(3, 8); // Casal D - Quarto 3
        g.addEdge(3, 10); // Casal D - Quarto 5
        g.addEdge(3, 11); // Casal D - Quarto 6

        g.addEdge(4, 8); // Casal E - Quarto 3
        g.addEdge(4, 9); // Casal E - Quarto 4
        g.addEdge(4, 10); // Casal E - Quarto 5
        g.addEdge(4, 11); // Casal E - Quarto 6

        g.addEdge(5, 7); // Casal F - Quarto 2
        g.addEdge(5, 10); // Casal F - Quarto 5

        int[] matchR = new int[12]; 
        int maxMatching = g.maxBipartiteMatching(matchR);
        System.out.println("O emparelhamento máximo é " + maxMatching);

        
        SwingUtilities.invokeLater(() -> {
            HotelCasais frame = new HotelCasais(matchR);
            frame.setVisible(true);
        });
    }
}
